import SwiftUI

struct Ajustes: View {
    var body: some View {
        Text("Hola")
    }
}
