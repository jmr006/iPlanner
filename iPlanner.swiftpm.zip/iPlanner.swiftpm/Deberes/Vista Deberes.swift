import SwiftUI

struct DeberesView: View {
    var body: some View {
        EventList()
    }
}
