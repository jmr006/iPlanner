import SwiftUI

struct EditorEvento: View {
    var body: some View {
        Text("Hola")
    }
}

struct EditorEvento_Previews: PreviewProvider {
    static var previews: some View {
        EditorEvento()
    }
}
