import SwiftUI

struct ExamenesView: View {
    var body: some View {
        Text("Hola")
    }
}

struct ExamenesView_Previews: PreviewProvider {
    static var previews: some View {
        ExamenesView()
    }
}
